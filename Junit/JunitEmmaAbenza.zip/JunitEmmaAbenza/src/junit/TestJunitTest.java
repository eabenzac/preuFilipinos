package junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestJunitTest {

	@Test
    public void test1() {
        assertEquals("SI", Codi.filipinos(-10.0, 5.0));
        assertEquals("SI", Codi.filipinos(-10.0, -10.0));
        assertEquals("NO", Codi.filipinos(-10.0, 6.0));
    }

    @Test
    public void test2() {
    	assertEquals("SI", Codi.filipinos(10.0, 14.0));
        assertEquals("NO", Codi.filipinos(10.0, 16.0)); 
        assertEquals("NO", Codi.filipinos(10.0, 15.0)); 
    }

    @Test
    public void test3() {
        assertEquals("SI", Codi.filipinos(0.0, -1.0));
        assertEquals("SI", Codi.filipinos(0.0, 0.0));
        assertEquals("NO", Codi.filipinos(0.0, 1.0));
    }
}
